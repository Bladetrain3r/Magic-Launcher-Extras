#!/usr/bin/env python3
"""
Spectrum Visualizer - Magic Launcher Edition
A configurable audio spectrum visualizer for recording backgrounds.

Dependencies:
    pip install sounddevice numpy pygame pillow

Usage:
    python spectrum.py                    # List audio devices
    python spectrum.py <device_index>     # Run with specific device
    python spectrum.py --config           # Show current config
"""

import sys
import threading
import queue
import numpy as np

# ============================================================================
# CONFIGURATION - Edit these to taste
# ============================================================================

CONFIG = {
    # Audio settings
    "sample_rate": 44100,
    "chunk_size": 2048,          # Larger = smoother but more latency
    "device": None,              # Set via command line, or hardcode index here
    
    # Spectrum settings
    "bands": 64,                 # Number of frequency bands (1-80)
    "min_freq": 20,              # Minimum frequency (Hz)
    "max_freq": 16000,           # Maximum frequency (Hz)
    "log_scale": True,           # Logarithmic frequency distribution
    
    # Visual settings
    "width": 1280,
    "height": 720,
    "fps": 60,
    "fullscreen": False,
    
    # Bar appearance
    "bar_color": (0, 255, 170),  # RGB - cyan-ish green
    "bar_color_top": (255, 0, 170),  # RGB - gradient top (magenta)
    "gradient": True,            # Use gradient coloring
    "bar_width_ratio": 0.8,      # Bar width as ratio of band width (0.1-1.0)
    "bar_max_height": 0.85,      # Max bar height as ratio of window height
    "opacity": 200,              # Bar opacity (0-255)
    
    # Background
    "background_image": None,    # Path to image, or None for solid color
    "background_color": (10, 10, 20),  # RGB if no image
    
    # Smoothing
    "smoothing": 0.3,            # 0 = no smoothing, 0.9 = very smooth
    "attack": 0.8,               # How fast bars rise (0-1)
    "decay": 0.2,                # How fast bars fall (0-1)
    
    # Amplitude
    "gain": 2.0,                 # Multiply signal strength
    "noise_floor": 0.01,         # Minimum threshold (reduces noise flicker)
}

# ============================================================================
# AUDIO CAPTURE
# ============================================================================

class AudioCapture:
    def __init__(self, device_index, sample_rate, chunk_size):
        import sounddevice as sd
        self.sd = sd
        self.device_index = device_index
        self.sample_rate = sample_rate
        self.chunk_size = chunk_size
        self.buffer = queue.Queue(maxsize=4)
        self.running = False
        self.stream = None
        
    def audio_callback(self, indata, frames, time_info, status):
        if status:
            print(f"Audio status: {status}", file=sys.stderr)
        # Take mono mix if stereo
        if len(indata.shape) > 1:
            mono = np.mean(indata, axis=1)
        else:
            mono = indata.flatten()
        
        try:
            self.buffer.put_nowait(mono.copy())
        except queue.Full:
            pass  # Drop frame if we're behind
    
    def start(self):
        self.running = True
        self.stream = self.sd.InputStream(
            device=self.device_index,
            channels=2,  # Capture stereo, mix to mono
            samplerate=self.sample_rate,
            blocksize=self.chunk_size,
            callback=self.audio_callback
        )
        self.stream.start()
        
    def stop(self):
        self.running = False
        if self.stream:
            self.stream.stop()
            self.stream.close()
    
    def get_chunk(self):
        try:
            return self.buffer.get_nowait()
        except queue.Empty:
            return None

# ============================================================================
# SPECTRUM ANALYSIS
# ============================================================================

class SpectrumAnalyzer:
    def __init__(self, config):
        self.config = config
        self.bands = config["bands"]
        self.sample_rate = config["sample_rate"]
        self.chunk_size = config["chunk_size"]
        
        # Pre-calculate frequency bin edges
        if config["log_scale"]:
            self.freq_edges = np.logspace(
                np.log10(config["min_freq"]),
                np.log10(config["max_freq"]),
                self.bands + 1
            )
        else:
            self.freq_edges = np.linspace(
                config["min_freq"],
                config["max_freq"],
                self.bands + 1
            )
        
        # FFT frequency bins
        self.fft_freqs = np.fft.rfftfreq(self.chunk_size, 1.0 / self.sample_rate)
        
        # Pre-calculate which FFT bins go into which band
        self.band_bins = []
        for i in range(self.bands):
            low = self.freq_edges[i]
            high = self.freq_edges[i + 1]
            bins = np.where((self.fft_freqs >= low) & (self.fft_freqs < high))[0]
            self.band_bins.append(bins)
        
        # Smoothed output
        self.smoothed = np.zeros(self.bands)
        
        # Window function for FFT
        self.window = np.hanning(self.chunk_size)
    
    def analyze(self, audio_chunk):
        if audio_chunk is None or len(audio_chunk) < self.chunk_size:
            return self.smoothed
        
        # Apply window and FFT
        windowed = audio_chunk[:self.chunk_size] * self.window
        fft = np.abs(np.fft.rfft(windowed))
        
        # Normalize
        fft = fft / self.chunk_size
        
        # Apply gain
        fft = fft * self.config["gain"]
        
        # Bin into bands
        band_values = np.zeros(self.bands)
        for i, bins in enumerate(self.band_bins):
            if len(bins) > 0:
                band_values[i] = np.mean(fft[bins])
        
        # Apply noise floor
        band_values = np.maximum(0, band_values - self.config["noise_floor"])
        
        # Convert to dB-ish scale (more perceptually linear)
        band_values = np.sqrt(band_values)  # Softer than log, looks better
        
        # Clamp to 0-1 range
        band_values = np.clip(band_values, 0, 1)
        
        # Apply attack/decay smoothing
        attack = self.config["attack"]
        decay = self.config["decay"]
        
        for i in range(self.bands):
            if band_values[i] > self.smoothed[i]:
                self.smoothed[i] += (band_values[i] - self.smoothed[i]) * attack
            else:
                self.smoothed[i] += (band_values[i] - self.smoothed[i]) * decay
        
        return self.smoothed

# ============================================================================
# RENDERER
# ============================================================================

class SpectrumRenderer:
    def __init__(self, config):
        import pygame
        self.pygame = pygame
        self.config = config
        
        pygame.init()
        
        flags = 0
        if config["fullscreen"]:
            flags |= pygame.FULLSCREEN
        
        self.screen = pygame.display.set_mode(
            (config["width"], config["height"]),
            flags
        )
        pygame.display.set_caption("Spectrum Visualizer")
        
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Load background image if specified
        self.background = None
        if config["background_image"]:
            try:
                img = pygame.image.load(config["background_image"])
                self.background = pygame.transform.scale(
                    img, (config["width"], config["height"])
                )
            except Exception as e:
                print(f"Could not load background: {e}", file=sys.stderr)
        
        # Create surface for bars (with alpha)
        self.bar_surface = pygame.Surface(
            (config["width"], config["height"]),
            pygame.SRCALPHA
        )
    
    def handle_events(self):
        for event in self.pygame.event.get():
            if event.type == self.pygame.QUIT:
                self.running = False
            elif event.type == self.pygame.KEYDOWN:
                if event.key == self.pygame.K_ESCAPE:
                    self.running = False
                elif event.key == self.pygame.K_f:
                    self.pygame.display.toggle_fullscreen()
    
    def lerp_color(self, c1, c2, t):
        """Linearly interpolate between two colors"""
        return (
            int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t),
        )
    
    def render(self, band_values):
        config = self.config
        width = config["width"]
        height = config["height"]
        bands = config["bands"]
        opacity = config["opacity"]
        
        # Clear bar surface
        self.bar_surface.fill((0, 0, 0, 0))
        
        # Calculate bar dimensions
        total_bar_width = width / bands
        bar_width = int(total_bar_width * config["bar_width_ratio"])
        bar_gap = (total_bar_width - bar_width) / 2
        max_height = int(height * config["bar_max_height"])
        
        # Draw bars
        for i, value in enumerate(band_values):
            bar_height = int(value * max_height)
            if bar_height < 2:
                bar_height = 2  # Minimum visible height
            
            x = int(i * total_bar_width + bar_gap)
            y = height - bar_height
            
            # Color (gradient or solid)
            if config["gradient"]:
                color = self.lerp_color(
                    config["bar_color"],
                    config["bar_color_top"],
                    value
                )
            else:
                color = config["bar_color"]
            
            # Add alpha
            color_with_alpha = (*color, opacity)
            
            self.pygame.draw.rect(
                self.bar_surface,
                color_with_alpha,
                (x, y, bar_width, bar_height)
            )
        
        # Draw background
        if self.background:
            self.screen.blit(self.background, (0, 0))
        else:
            self.screen.fill(config["background_color"])
        
        # Draw bars on top
        self.screen.blit(self.bar_surface, (0, 0))
        
        self.pygame.display.flip()
        self.clock.tick(config["fps"])
    
    def quit(self):
        self.pygame.quit()

# ============================================================================
# MAIN
# ============================================================================

def list_devices():
    import sounddevice as sd
    print("\nAvailable audio devices:\n")
    print(sd.query_devices())
    print("\nLook for 'Monitor' devices to capture system audio.")
    print("Usage: python spectrum.py <device_index>")

def show_config():
    print("\nCurrent configuration:\n")
    for key, value in CONFIG.items():
        print(f"  {key}: {value}")
    print("\nEdit the CONFIG dict at the top of the script to customize.")

def main():
    if len(sys.argv) < 2:
        list_devices()
        return
    
    if sys.argv[1] == "--config":
        show_config()
        return
    
    try:
        device_index = int(sys.argv[1])
    except ValueError:
        print(f"Invalid device index: {sys.argv[1]}")
        return
    
    CONFIG["device"] = device_index
    
    print(f"Starting spectrum visualizer with device {device_index}")
    print("Press ESC to quit, F for fullscreen")
    
    # Initialize components
    audio = AudioCapture(
        device_index,
        CONFIG["sample_rate"],
        CONFIG["chunk_size"]
    )
    analyzer = SpectrumAnalyzer(CONFIG)
    renderer = SpectrumRenderer(CONFIG)
    
    # Start audio capture
    audio.start()
    
    try:
        while renderer.running:
            renderer.handle_events()
            
            # Get audio and analyze
            chunk = audio.get_chunk()
            band_values = analyzer.analyze(chunk)
            
            # Render
            renderer.render(band_values)
    
    except KeyboardInterrupt:
        pass
    finally:
        audio.stop()
        renderer.quit()
        print("Goodbye!")

if __name__ == "__main__":
    main()
